import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

print("Starting IPL Data Analysis Pipeline...")

# Load Data
try:
    matches = pd.read_csv('matches.csv')
    deliveries = pd.read_csv('deliveries.csv')
    print("✅ Datasets loaded successfully.")
except FileNotFoundError as e:
    print(f"❌ Error: {e}. Ensure csv files are in the same folder.")
    exit()

# Chart 1: Team Wins
plt.figure(figsize=(10, 5))
sns.countplot(y='winner', data=matches, order=matches['winner'].value_counts().index, palette='coolwarm')
plt.title('IPL Most Successful Teams')
plt.xlabel('Total Matches Won')
plt.ylabel('Teams')
plt.tight_layout()
plt.savefig('ipl_team_wins.png')
print("💾 Generated: ipl_team_wins.png")

# Chart 2: Toss Decision Analysis
plt.figure(figsize=(6, 6))
matches['toss_decision'].value_counts().plot(kind='pie', autopct='%1.1f%%', colors=['#4CAF50', '#FF9800'], startangle=90)
plt.title('IPL Toss Strategic Choices (Bat vs Field)')
plt.ylabel('')
plt.tight_layout()
plt.savefig('ipl_toss_choices.png')
print("💾 Generated: ipl_toss_choices.png")

# Chart 3: Top Run Scorers from ball-by-ball data
plt.figure(figsize=(10, 5))
top_batsmen = deliveries.groupby('batsman')['batsman_runs'].sum().sort_values(ascending=False).head(5)
sns.barplot(x=top_batsmen.values, y=top_batsmen.index, palette='mako')
plt.title('Top 5 Run Scorers (Sample Representation)')
plt.xlabel('Total Runs')
plt.ylabel('Batsmen')
plt.tight_layout()
plt.savefig('ipl_top_batsmen.png')
print("💾 Generated: ipl_top_batsmen.png")

print("\n📊 IPL Analysis pipeline completed successfully!")
